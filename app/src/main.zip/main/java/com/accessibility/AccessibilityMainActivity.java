package com.accessibility;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.accessibility.utils.AppInfo;
import com.accessibility.utils.Constant;
import com.accessibility.utils.Util;

import java.util.ArrayList;

public class AccessibilityMainActivity extends Activity implements View.OnClickListener {
    private View mOpenSetting;
//    private Handler mHandler = new Handler(Looper.getMainLooper());
    private ArrayList<AppInfo> mAppList = Constant.getAppList();
    private int mCurAppIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accessibility_main);
        initView();
        AccessibilityOperator.getInstance().init(this);
    }
    
    private void initView() {
        mOpenSetting = findViewById(R.id.open_accessibility_setting);
        mOpenSetting.setOnClickListener(this);
        findViewById(R.id.accessibility_find_and_click).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        final int id = v.getId();   
        switch (id) {
            case R.id.open_accessibility_setting:
                OpenAccessibilitySettingHelper.jumpToSettingPage(this);
                break;
            case R.id.accessibility_find_and_click:
                Util.startActivity(mAppList.get(mCurAppIndex), this);
                break;
        }
    }
}
