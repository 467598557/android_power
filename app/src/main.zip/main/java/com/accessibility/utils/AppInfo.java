package com.accessibility.utils;

public class AppInfo {
    public String packageName;
    public String startComponent;
    public String mainComponent;
    public String newComponent;
    public String videoComponent;

    AppInfo(String packageName, String startComponent, String mainComponent, String newComponent, String videoComponent) {
        this.packageName = packageName;
        this.startComponent = startComponent;
        this.mainComponent = mainComponent;
        this.newComponent = newComponent;
        this.videoComponent = videoComponent;
    }
}
