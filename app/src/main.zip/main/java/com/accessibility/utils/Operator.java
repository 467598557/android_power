package com.accessibility.utils;

import android.content.Context;
import android.widget.Toast;

public class Operator {
    public static boolean isRunning = false;

    public static void start(Context context) {
        if(isRunning) {
            Toast.makeText(context, "服务正在启动中", Toast.LENGTH_SHORT).show();
            return;
        }

        isRunning = true;
        while(true) {

        }
    }
}
