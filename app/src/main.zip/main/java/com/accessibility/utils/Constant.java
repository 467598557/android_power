package com.accessibility.utils;

import java.util.ArrayList;

public class Constant {
    public static ArrayList<AppInfo> mAppList = new ArrayList<AppInfo>();
    private static String[] mAppPackages = {
            "com.jifen.qukan",
            "com.xiangzi.jukandian",
            "cn.weli.story",
            "com.huolea.bull",
    };
    private static String[] mAppStartComponents = {
            "com.jifen.qkbase.main.MainActivity",
            "com.xiangzi.jukandian.activity.V2WelcomeActivity",
            "cn.etouch.ecalendar.MainActivity",
            "com.huolea.bull.page.other.activity.SplashActivity"
    };
    private static String[] mAppMainComponents = {
            "com.jifen.qkbase.main.MainActivity",
            "com.xiangzi.jukandian.activity.MainActivity",
            "cn.etouch.ecalendar.MainActivity",
            "com.huolea.bull.page.other.activity.MainActivity"
    };
    private static String[] mAppNewComponents = {
            "com.jifen.qukan.content.newsdetail.news.NewsDetailNewActivity",
            "com.xiangzi.jukandian.activity.WebViewActivity",
            "cn.etouch.ecalendar.tools.life.LifeDetailsActivity",
            "com.huolea.bull.page.news.activity.NewsDetailActivity"
    };
    private static String[] mAppVideoComponents = {
            "com.jifen.qukan.content.newsdetail.video.VideoNewsDetailNewActivity",
            "com.xiangzi.jukandian.activity.WebViewActivity",
            "cn.etouch.ecalendar.tools.life.LifeDetailsActivity",
            "com.huolea.bull.page.news.activity.NewsDetailActivity"
    };

    public static ArrayList<AppInfo> getAppList() {
        if (mAppList.size() == 0) {
            for (int i = 0; i < mAppPackages.length; i++) {
                mAppList.add(new AppInfo(mAppPackages[i], mAppStartComponents[i], mAppMainComponents[i], mAppNewComponents[i], mAppVideoComponents[i]));
            }
        }

        return mAppList;
    }
}
