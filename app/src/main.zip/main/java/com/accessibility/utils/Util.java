package com.accessibility.utils;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;

public class Util {
    public static boolean startActivity(AppInfo appInfo, Context context) {
        try {
            Intent intent = new Intent();
            intent.setAction("Android.intent.action.VIEW");
            intent.setClassName(appInfo.packageName,
                    appInfo.startComponent);
            context.startActivity(intent);

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
